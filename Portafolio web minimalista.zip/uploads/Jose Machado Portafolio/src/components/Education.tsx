"use client";

import { useLanguage } from "@/lib/language";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";

export default function Education() {
  const { t } = useLanguage();

  return (
    <section id="education" className="hairline relative scroll-mt-16">
      <div className="mx-auto max-w-6xl px-6 py-24 md:px-8 md:py-32">
        <SectionHeading label={t.education.label} title={t.education.title} />

        <div className="grid gap-5 md:grid-cols-2 md:gap-6">
          {t.education.schools.map((school, i) => (
            <Reveal key={school.school} delay={i * 0.08}>
              <div className="flex h-full flex-col rounded-2xl border border-line bg-surface p-7 transition-colors hover:bg-raise md:p-9">
                <div className="flex items-baseline justify-between gap-4">
                  <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-accent">
                    {school.period}
                  </p>
                  <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-faint">
                    {school.location}
                  </p>
                </div>
                <h3 className="mt-5 font-display text-2xl text-cream md:text-3xl">
                  {school.school}
                </h3>
                <p className="mt-2 text-sm font-medium text-accent">
                  {school.program}
                </p>
                <p className="mt-4 text-[15px] leading-[1.75] text-muted">
                  {school.detail}
                </p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
