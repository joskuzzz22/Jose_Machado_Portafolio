"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useInView, useReducedMotion } from "framer-motion";
import { useLanguage } from "@/lib/language";
import type { SkillKey } from "@/lib/content";

const COLS = 5;

export default function SkillKeyboard() {
  const { t } = useLanguage();
  const keys = t.skills.keyboard.keys;

  const [pressed, setPressed] = useState<Set<string>>(new Set());
  const [active, setActive] = useState<SkillKey | null>(null);
  const boardRef = useRef<HTMLDivElement>(null);
  const inView = useInView(boardRef, { once: true, margin: "-80px" });
  const reduce = useReducedMotion();
  const wavePlayed = useRef(false);

  const press = useCallback((k: string) => {
    setPressed((prev) => {
      if (prev.has(k)) return prev;
      const next = new Set(prev);
      next.add(k);
      return next;
    });
  }, []);

  const release = useCallback((k: string) => {
    setPressed((prev) => {
      if (!prev.has(k)) return prev;
      const next = new Set(prev);
      next.delete(k);
      return next;
    });
  }, []);

  // Physical keyboard binding
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey || e.altKey || e.repeat) return;
      const target = e.target as HTMLElement | null;
      if (target && /^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName)) return;
      const k = e.key.toUpperCase();
      const match = keys.find((key) => key.k === k);
      if (match) {
        press(k);
        setActive(match);
      }
    };
    const up = (e: KeyboardEvent) => {
      release(e.key.toUpperCase());
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, [keys, press, release]);

  // One-time diagonal wave when the board scrolls into view
  useEffect(() => {
    if (!inView || wavePlayed.current || reduce) return;
    wavePlayed.current = true;
    const timers: ReturnType<typeof setTimeout>[] = [];
    keys.forEach((key, i) => {
      const row = Math.floor(i / COLS);
      const col = i % COLS;
      const delay = 350 + (row + col) * 70;
      timers.push(setTimeout(() => press(key.k), delay));
      timers.push(setTimeout(() => release(key.k), delay + 220));
    });
    return () => timers.forEach(clearTimeout);
  }, [inView, keys, press, release, reduce]);

  const toneClass = (tone?: string) =>
    tone === "accent"
      ? "keycap--accent"
      : tone === "mid"
        ? "keycap--mid"
        : "keycap--base";

  return (
    <div className="mb-16 md:mb-20">
      <p className="mb-2 text-center font-mono text-[10px] uppercase tracking-[0.25em] text-faint">
        {t.skills.keyboard.hint}
      </p>

      {/* Stage — fixed heights per breakpoint; the board is scaled inside */}
      <div
        ref={boardRef}
        className="relative flex h-[330px] items-center justify-center overflow-hidden sm:h-[400px] md:h-[470px]"
        style={{ perspective: "1400px" }}
      >
        <div className="scale-[0.52] sm:scale-[0.72] md:scale-[0.88] lg:scale-100">
          <div
            className="kb-board grid gap-3"
            style={{ gridTemplateColumns: `repeat(${COLS}, 86px)` }}
          >
            {keys.map((key) => (
              <button
                key={key.k}
                type="button"
                className={`keycap ${toneClass(key.tone)} ${
                  pressed.has(key.k) ? "is-pressed" : ""
                }`}
                aria-label={`${key.label} — ${key.blurb}`}
                onPointerDown={() => {
                  press(key.k);
                  setActive(key);
                }}
                onPointerUp={() => release(key.k)}
                onPointerLeave={() => release(key.k)}
                onKeyDown={(e) => {
                  // Space/Enter on a focused cap: press it like a key
                  if (e.key === " " || e.key === "Enter") {
                    e.preventDefault();
                    press(key.k);
                    setActive(key);
                  }
                }}
                onKeyUp={(e) => {
                  if (e.key === " " || e.key === "Enter") release(key.k);
                }}
              >
                <span className="absolute top-2 left-2.5 font-mono text-[11px] opacity-45">
                  {key.k}
                </span>
                <span className="font-mono text-[10px] font-medium uppercase leading-tight tracking-[0.08em]">
                  {key.label}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Readout */}
      <div
        aria-live="polite"
        className="mx-auto mt-2 flex min-h-[56px] max-w-xl items-center justify-center rounded-xl border border-line bg-surface px-6 py-3 text-center"
      >
        {active ? (
          <p className="text-sm leading-relaxed text-muted">
            <span className="mr-2 font-mono text-[11px] text-accent">
              [{active.k}]
            </span>
            <span className="font-medium text-cream">{active.label}</span>
            <span className="mx-2 text-faint">—</span>
            {active.blurb}
          </p>
        ) : (
          <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-faint">
            <span className="mr-2 inline-block h-3 w-1.5 animate-pulse bg-accent align-middle" />
            {t.skills.keyboard.idle}
          </p>
        )}
      </div>
    </div>
  );
}
