"use client";

import { useLanguage } from "@/lib/language";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";

export default function Experience() {
  const { t } = useLanguage();

  return (
    <section id="experience" className="hairline relative scroll-mt-16">
      <div className="mx-auto max-w-6xl px-6 py-24 md:px-8 md:py-32">
        <SectionHeading label={t.experience.label} title={t.experience.title} />

        <div className="space-y-16 md:space-y-20">
          {t.experience.entries.map((entry, ei) => (
            <Reveal key={entry.company} delay={ei * 0.05}>
              <div className="grid gap-6 md:grid-cols-[280px_1fr] md:gap-12">
                {/* Company column */}
                <div className="md:sticky md:top-24 md:self-start">
                  <h3 className="font-display text-2xl text-cream md:text-3xl">
                    {entry.company}
                  </h3>
                  <p className="mt-2 font-mono text-[10px] uppercase tracking-[0.2em] text-accent">
                    {entry.kind}
                  </p>
                  <p className="mt-1 font-mono text-[10px] uppercase tracking-[0.2em] text-faint">
                    {entry.location}
                  </p>
                </div>

                {/* Roles column */}
                <div className="relative space-y-10 border-l border-line pl-8 md:space-y-12">
                  {entry.roles.map((role) => (
                    <div key={role.title} className="relative">
                      <span
                        aria-hidden
                        className="absolute -left-[37px] top-2 h-2 w-2 rounded-full border border-accent bg-ink"
                      />
                      <div className="flex flex-wrap items-baseline justify-between gap-2">
                        <h4 className="text-lg font-medium text-cream">
                          {role.title}
                        </h4>
                        <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-accent">
                          {role.period}
                        </p>
                      </div>
                      <ul className="mt-4 space-y-3">
                        {role.bullets.map((b, bi) => (
                          <li
                            key={bi}
                            className="flex gap-3 text-[15px] leading-[1.75] text-muted"
                          >
                            <span
                              aria-hidden
                              className="mt-[11px] h-px w-4 shrink-0 bg-accent/50"
                            />
                            {b}
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
