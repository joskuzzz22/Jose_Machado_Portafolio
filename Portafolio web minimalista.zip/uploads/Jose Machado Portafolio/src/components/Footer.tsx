"use client";

import { useLanguage } from "@/lib/language";

export default function Footer() {
  const { t } = useLanguage();

  return (
    <footer className="hairline">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-6 py-10 text-center md:flex-row md:px-8 md:text-left">
        <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-faint">
          {t.footer.rights}
        </p>
        <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-faint">
          {t.footer.built}
        </p>
      </div>
    </footer>
  );
}
