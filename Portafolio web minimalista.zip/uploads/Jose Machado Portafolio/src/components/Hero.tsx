"use client";

import { motion, useReducedMotion } from "framer-motion";
import { useLanguage } from "@/lib/language";

export default function Hero() {
  const { t } = useLanguage();
  const reduce = useReducedMotion();

  const fade = (delay: number) => ({
    initial: { opacity: 0, y: reduce ? 0 : 30 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.8, delay, ease: [0.21, 0.47, 0.32, 0.98] as const },
  });

  return (
    <section
      id="top"
      className="relative flex min-h-svh flex-col justify-center overflow-hidden"
    >
      {/* Ambient glow */}
      <div
        aria-hidden
        className="pointer-events-none absolute -top-1/3 left-1/2 h-[80vh] w-[120vw] -translate-x-1/2 rounded-full opacity-[0.16]"
        style={{
          background:
            "radial-gradient(ellipse at center, #c9a96e 0%, transparent 62%)",
        }}
      />
      {/* Vertical hairlines */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 mx-auto hidden max-w-6xl justify-between px-6 md:flex md:px-8"
      >
        <span className="h-full w-px bg-line/60" />
        <span className="h-full w-px bg-line/60" />
      </div>

      <div className="relative mx-auto w-full max-w-6xl px-6 pt-28 pb-16 md:px-8 md:pt-32">
        <motion.p
          {...fade(0.05)}
          className="font-mono text-[11px] uppercase tracking-[0.3em] text-accent md:text-xs"
        >
          {t.hero.eyebrow}
        </motion.p>

        <motion.h1
          {...fade(0.18)}
          className="mt-8 max-w-5xl font-display text-[2.6rem] leading-[1.04] text-cream sm:text-6xl md:text-7xl lg:text-[5.2rem]"
        >
          {t.hero.headline1}{" "}
          <em className="text-accent">{t.hero.headlineAccent}</em>{" "}
          {t.hero.headline2}
        </motion.h1>

        <motion.p
          {...fade(0.32)}
          className="mt-8 max-w-2xl text-base leading-relaxed text-muted md:text-lg"
        >
          {t.hero.sub}
        </motion.p>

        <motion.div {...fade(0.44)} className="mt-10 flex flex-wrap gap-4">
          <a
            href="#contact"
            className="group inline-flex items-center gap-3 rounded-full bg-accent px-7 py-3.5 text-sm font-medium text-ink transition-all hover:brightness-110"
          >
            {t.hero.ctaPrimary}
            <span className="transition-transform group-hover:translate-x-1">
              →
            </span>
          </a>
          <a
            href="#projects"
            className="inline-flex items-center gap-3 rounded-full border border-line-strong px-7 py-3.5 text-sm text-cream transition-all hover:border-accent hover:text-accent"
          >
            {t.hero.ctaSecondary}
          </a>
        </motion.div>

        {/* Stats band */}
        <motion.div
          {...fade(0.58)}
          className="mt-20 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-line bg-line md:mt-24 md:grid-cols-4"
        >
          {t.hero.stats.map((s) => (
            <div
              key={s.label}
              className="bg-surface px-6 py-6 transition-colors duration-300 hover:bg-raise md:px-8 md:py-8"
            >
              <p className="font-display text-3xl text-accent md:text-4xl">
                {s.value}
              </p>
              <p className="mt-2 font-mono text-[10px] uppercase leading-relaxed tracking-[0.14em] text-muted">
                {s.label}
              </p>
            </div>
          ))}
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.4, duration: 1 }}
        className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 md:block"
      >
        <p className="animate-pulse font-mono text-[10px] uppercase tracking-[0.3em] text-faint">
          {t.hero.scroll} ↓
        </p>
      </motion.div>
    </section>
  );
}
