"use client";

import { useLanguage } from "@/lib/language";
import type { Project } from "@/lib/content";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";

function ProjectCard({ project, delay }: { project: Project; delay: number }) {
  return (
    <Reveal
      delay={delay}
      className={project.featured ? "md:col-span-2" : undefined}
    >
      <article
        className={`group relative flex h-full flex-col overflow-hidden rounded-2xl border border-line bg-surface p-7 transition-all duration-500 hover:-translate-y-1 hover:border-accent/40 hover:bg-raise md:p-9 ${
          project.featured ? "md:flex-row md:items-end md:gap-12" : ""
        }`}
      >
        {/* Hover glow */}
        <div
          aria-hidden
          className="pointer-events-none absolute -top-24 -right-24 h-48 w-48 rounded-full bg-accent/10 opacity-0 blur-3xl transition-opacity duration-700 group-hover:opacity-100"
        />

        <div className="relative flex-1">
          <div className="flex items-baseline justify-between gap-4">
            <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-faint">
              {project.index}
            </p>
            <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-accent">
              {project.role}
            </p>
          </div>

          <h3
            className={`mt-5 font-display text-cream transition-colors group-hover:text-accent ${
              project.featured ? "text-3xl md:text-5xl" : "text-2xl md:text-[1.7rem]"
            }`}
          >
            {project.title}
          </h3>

          <p className="mt-4 max-w-xl text-[15px] leading-[1.75] text-muted">
            {project.description}
          </p>

          <div className="mt-6 flex flex-wrap gap-2">
            {project.tags.map((tag) => (
              <span
                key={tag}
                className="rounded-full border border-line px-3 py-1 font-mono text-[10px] uppercase tracking-[0.12em] text-muted transition-colors group-hover:border-line-strong"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>

        <div
          className={`relative mt-8 border-t border-line pt-6 ${
            project.featured
              ? "md:mt-0 md:min-w-[200px] md:border-t-0 md:border-l md:pt-0 md:pl-12"
              : ""
          }`}
        >
          <p className="font-display text-4xl text-accent md:text-5xl">
            {project.metric}
          </p>
          <p className="mt-2 font-mono text-[10px] uppercase leading-relaxed tracking-[0.14em] text-muted">
            {project.metricLabel}
          </p>
        </div>
      </article>
    </Reveal>
  );
}

export default function Projects() {
  const { t } = useLanguage();

  return (
    <section id="projects" className="hairline relative scroll-mt-16">
      <div className="mx-auto max-w-6xl px-6 py-24 md:px-8 md:py-32">
        <SectionHeading label={t.projects.label} title={t.projects.title} />

        <Reveal>
          <p className="-mt-8 mb-14 max-w-2xl text-base leading-relaxed text-muted md:mb-16">
            {t.projects.intro}
          </p>
        </Reveal>

        <div className="grid gap-5 md:grid-cols-2 md:gap-6">
          {t.projects.items.map((p, i) => (
            <ProjectCard key={p.index} project={p} delay={(i % 2) * 0.08} />
          ))}
        </div>
      </div>
    </section>
  );
}
