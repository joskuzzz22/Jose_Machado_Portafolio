"use client";

import { useLanguage } from "@/lib/language";
import Reveal from "./Reveal";

export default function Contact() {
  const { t } = useLanguage();

  return (
    <section id="contact" className="hairline relative scroll-mt-16 overflow-hidden">
      {/* Ambient glow */}
      <div
        aria-hidden
        className="pointer-events-none absolute bottom-0 left-1/2 h-[60vh] w-[110vw] -translate-x-1/2 translate-y-1/2 rounded-full opacity-[0.13]"
        style={{
          background:
            "radial-gradient(ellipse at center, #c9a96e 0%, transparent 62%)",
        }}
      />

      <div className="relative mx-auto max-w-6xl px-6 py-28 text-center md:px-8 md:py-40">
        <Reveal>
          <p className="font-mono text-[11px] uppercase tracking-[0.25em] text-accent">
            {t.contact.label}
          </p>
        </Reveal>

        <Reveal delay={0.08}>
          <h2 className="mx-auto mt-6 max-w-3xl font-display text-5xl leading-[1.05] text-cream md:text-7xl">
            {t.contact.title1}{" "}
            <em className="text-accent">{t.contact.titleAccent}</em>.
          </h2>
        </Reveal>

        <Reveal delay={0.16}>
          <p className="mx-auto mt-8 max-w-xl text-base leading-relaxed text-muted md:text-lg">
            {t.contact.sub}
          </p>
        </Reveal>

        <Reveal delay={0.24}>
          <div className="mt-12 flex flex-wrap items-center justify-center gap-4">
            <a
              href="mailto:Joskuzzz22@gmail.com"
              className="group inline-flex items-center gap-3 rounded-full bg-accent px-8 py-4 text-sm font-medium text-ink transition-all hover:brightness-110"
            >
              {t.contact.emailCta}
              <span className="transition-transform group-hover:translate-x-1">
                →
              </span>
            </a>
            <a
              href="https://linkedin.com/in/josemachado"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 rounded-full border border-line-strong px-8 py-4 text-sm text-cream transition-all hover:border-accent hover:text-accent"
            >
              {t.contact.linkedinCta} ↗
            </a>
          </div>
        </Reveal>

        <Reveal delay={0.32}>
          <p className="mt-12 inline-flex items-center gap-2.5 rounded-full border border-line px-5 py-2.5 font-mono text-[10px] uppercase tracking-[0.18em] text-muted">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-accent opacity-60" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-accent" />
            </span>
            {t.contact.availability}
          </p>
        </Reveal>
      </div>
    </section>
  );
}
