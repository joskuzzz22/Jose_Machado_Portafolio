"use client";

import { useLanguage } from "@/lib/language";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";

export default function About() {
  const { t } = useLanguage();

  return (
    <section id="about" className="hairline relative scroll-mt-16">
      <div className="mx-auto max-w-6xl px-6 py-24 md:px-8 md:py-32">
        <SectionHeading label={t.about.label} title={t.about.title} />

        <div className="grid gap-14 lg:grid-cols-[1.6fr_1fr] lg:gap-20">
          <div className="space-y-6">
            {t.about.paragraphs.map((p, i) => (
              <Reveal key={i} delay={i * 0.08}>
                <p className="text-base leading-[1.85] text-muted md:text-lg">
                  {p}
                </p>
              </Reveal>
            ))}
          </div>

          <Reveal delay={0.15}>
            <dl className="space-y-0 overflow-hidden rounded-2xl border border-line">
              {t.about.facts.map((f, i) => (
                <div
                  key={f.label}
                  className={`bg-surface px-6 py-5 transition-colors hover:bg-raise ${
                    i > 0 ? "border-t border-line" : ""
                  }`}
                >
                  <dt className="font-mono text-[10px] uppercase tracking-[0.2em] text-accent">
                    {f.label}
                  </dt>
                  <dd className="mt-1.5 text-sm leading-relaxed text-cream">
                    {f.value}
                  </dd>
                </div>
              ))}
            </dl>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
