"use client";

import { useLanguage } from "@/lib/language";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";
import SkillKeyboard from "./SkillKeyboard";

export default function Skills() {
  const { t } = useLanguage();

  return (
    <section id="skills" className="hairline relative scroll-mt-16">
      <div className="mx-auto max-w-6xl px-6 py-24 md:px-8 md:py-32">
        <SectionHeading label={t.skills.label} title={t.skills.title} />

        <Reveal>
          <SkillKeyboard />
        </Reveal>

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4 md:gap-6">
          {t.skills.groups.map((group, gi) => (
            <Reveal key={group.title} delay={gi * 0.07}>
              <div className="flex h-full flex-col rounded-2xl border border-line bg-surface p-6 transition-colors hover:bg-raise md:p-7">
                <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-accent">
                  {String(gi + 1).padStart(2, "0")}
                </p>
                <h3 className="mt-3 font-display text-xl text-cream md:text-2xl">
                  {group.title}
                </h3>
                <ul className="mt-5 space-y-2.5 border-t border-line pt-5">
                  {group.items.map((item) => (
                    <li
                      key={item}
                      className="text-[13.5px] leading-relaxed text-muted"
                    >
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>
          ))}
        </div>

        {/* Certifications */}
        <Reveal delay={0.1}>
          <div className="mt-16 md:mt-20">
            <h3 className="mb-8 font-display text-2xl text-cream md:text-3xl">
              {t.skills.certsTitle}
            </h3>
            <div className="overflow-hidden rounded-2xl border border-line">
              {t.skills.certs.map((cert, i) => (
                <div
                  key={cert.name}
                  className={`flex flex-col gap-1 bg-surface px-6 py-4 transition-colors hover:bg-raise sm:flex-row sm:items-center sm:justify-between sm:gap-6 md:px-8 ${
                    i > 0 ? "border-t border-line" : ""
                  }`}
                >
                  <div className="flex-1">
                    <p className="text-sm leading-relaxed text-cream">
                      {cert.name}
                    </p>
                  </div>
                  <div className="flex items-center gap-4 sm:gap-6">
                    <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-muted">
                      {cert.issuer}
                    </p>
                    <p className="min-w-[110px] text-right font-mono text-[10px] uppercase tracking-[0.16em] text-accent">
                      {cert.year}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
