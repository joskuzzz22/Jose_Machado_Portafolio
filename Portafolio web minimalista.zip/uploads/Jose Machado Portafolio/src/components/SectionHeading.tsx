"use client";

import Reveal from "./Reveal";

interface SectionHeadingProps {
  label: string;
  title: string;
}

export default function SectionHeading({ label, title }: SectionHeadingProps) {
  return (
    <div className="mb-14 md:mb-20">
      <Reveal>
        <p className="font-mono text-[11px] uppercase tracking-[0.25em] text-accent">
          {label}
        </p>
      </Reveal>
      <Reveal delay={0.08}>
        <h2 className="mt-4 font-display text-4xl leading-[1.08] text-cream md:text-6xl">
          {title}
        </h2>
      </Reveal>
    </div>
  );
}
