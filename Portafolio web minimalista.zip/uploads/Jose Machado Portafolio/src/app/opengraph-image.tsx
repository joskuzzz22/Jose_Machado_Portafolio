import { ImageResponse } from "next/og";

export const alt =
  "José Machado — AI Solutions Engineer & Digital Transformation Product Owner";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function OpenGraphImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          padding: 72,
          backgroundColor: "#0a0a0e",
          backgroundImage:
            "radial-gradient(ellipse 900px 500px at 50% -10%, rgba(201,169,110,0.22), transparent)",
          color: "#edeae3",
          fontFamily: "Georgia, serif",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            fontSize: 24,
            letterSpacing: 6,
            textTransform: "uppercase",
            color: "#c9a96e",
          }}
        >
          <span>José Leonardo Machado Tabraj</span>
          <span>Lima, Perú</span>
        </div>

        <div
          style={{
            display: "flex",
            flexDirection: "column",
            gap: 24,
          }}
        >
          <div style={{ fontSize: 76, lineHeight: 1.1, display: "flex", flexWrap: "wrap" }}>
            AI-powered products. Measurable outcomes.
          </div>
          <div
            style={{
              fontSize: 30,
              color: "#918f99",
              fontFamily: "Arial, sans-serif",
            }}
          >
            AI Solutions Engineer · Digital Transformation Product Owner · SAP
          </div>
        </div>

        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            borderTop: "1px solid rgba(237,234,227,0.18)",
            paddingTop: 32,
            fontSize: 26,
            fontFamily: "Arial, sans-serif",
            color: "#918f99",
          }}
        >
          <span style={{ display: "flex", gap: 40 }}>
            <span>7+ products in production</span>
            <span style={{ color: "#c9a96e" }}>·</span>
            <span>MCP · SAP · LLMs</span>
          </span>
          <span style={{ color: "#c9a96e", fontFamily: "Georgia, serif", fontStyle: "italic", fontSize: 34 }}>
            JM.
          </span>
        </div>
      </div>
    ),
    { ...size }
  );
}
